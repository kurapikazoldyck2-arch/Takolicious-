# TakoLicious Website

A cute pink, mobile-friendly website for the TakoLicious school project.

## Included
- `index.html` — website content and menu
- `style.css` — pink responsive design
- `script.js` — small navigation enhancement
- `images/` — supplied TakoLicious poster and menu images

## Menu
- Sisig — ₱60
- Chocolate — ₱60
- Cheese — ₱60
- Ham and Cheese — ₱70
- Bottled Water — ₱20
- Softdrinks — ₱15

## Location and contact
- Parian, Mexico, Pampanga
- (0994) 026 5005
- Facebook: https://www.facebook.com/share/19R3rQnofo/?mibextid=wwXIfr
- TikTok: https://www.tiktok.com/@takolicious7?_r=1&_t=ZS-9AY3MeLd

## Publish with GitHub Pages
1. Upload the files to a GitHub repository.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch `main` and folder `/ (root)`, then press **Save**.
5. Wait for GitHub Pages to publish the site.

This project uses plain HTML, CSS, and JavaScript; no build step is required.
